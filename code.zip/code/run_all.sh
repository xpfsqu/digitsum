#!/bin/sh
# Reproduces every computational statement, table and figure of the paper.
# Pass "full" to include the slowest checks (a few minutes more).
set -e
cd "$(dirname "$0")/src"
FULL="$1"

echo "[1/6] cycles of T and the convergent classes    (Lemma 3.1, Theorem 1.1, Table 1)"
python3 verify_cycles.py > /dev/null

echo "[2/6] the nine-step bound                        (Lemma 4.1, Theorem 1.2, Remark 4.2)"
python3 verify_step_bound.py 60000 > /dev/null

echo "[3/6] digit constructions and the witnesses      (Lemmas 5.1-5.3, Theorem 5.4, Remark 5.5)"
python3 witness.py > /dev/null

echo "[4/6] one step of the chain construction         (Lemma 5.7, Theorem 5.8, Remark 5.9)"
python3 chain_step.py $FULL > /dev/null

echo "[5/6] arbitrary bases                            (Lemma 6.1, Theorem 1.4, Table 3, Remark 6.2)"
python3 general_base.py > /dev/null

echo "[6/6] exact distribution, figures, brute force   (Table 2, Figures 1-2)"
python3 distribution.py > /dev/null
gcc -O2 -o brute_force brute_force.c
./brute_force 8 > ../results/brute_force_1e8.txt
python3 - <<'PY'
import json
d = json.load(open("../results/distribution.json"))["exact_counts"]
bf = {}
for line in open("../results/brute_force_1e8.txt"):
    if line.startswith("k="):
        k, rest = line.split(":", 1)
        bf[k[2:]] = {int(a.split(":")[0]): int(a.split(":")[1]) for a in rest.split()}
ok = all(bf[k] == {int(a): b for a, b in d[k].items()} for k in bf)
print("      brute force agrees with the exact counts for k = 1..8:", ok)
assert ok
PY
rm -f brute_force
echo "done.  Results are in ../results, figures in ../figures."
