"""Explicit counterexamples to the nine-step bound (base 10).

(1) Lemma (repunit block): S(c(10^m - 1)) = 9m for 1 <= c <= 10^m.
(2) Lemma (block construction): for a B_2-set E with r elements,
    V = sum 10^e, W = 10^m - 1 (2V <= 10^m) and 10^a > max(V^2, 2VW),
    the number x = 10^a W + V satisfies S(x^2) = 18m + r^2.
(3) Lemma (tail construction): if 5 !| v, v^2 < 10^g and 2g <= h, then
    s = 10^h - 10^g + v satisfies S(s^2) = 9h + S(v^2).
(4) The 60-digit witness s0 = 10^60 - 10^30 + v0, v0 = 948683297970914:
    S(v0^2) = 232, S(s0^2) = 772 and sigma(s0^2) = 9, so every even n with
    S(n) = s0 has sigma(n) = 10.
(5) The 93-digit witness coming from (2) with E = {1,2,4,8}, m = 42.
"""
import json, random
from digitmap import S, stopping_time, phi

def block_x(E, m):
    V = sum(10 ** e for e in E)
    W = 10 ** m - 1
    assert 2 * V <= 10 ** m
    a = max(len(str(V * V)), len(str(2 * V * W)))
    return 10 ** a * W + V

def is_B2(E):
    s = [e + f for i, e in enumerate(E) for f in E[i:]]
    return len(s) == len(set(s))

# (1) repunit block lemma
rng = random.Random(11)
for _ in range(4000):
    m = rng.randrange(1, 40)
    c = rng.randrange(1, 10 ** m + 1)
    assert S(c * (10 ** m - 1)) == 9 * m

# (2) block lemma with the sets E_0(r) = {3^j} and E_1(r) = {0} u {3^j}
for r in range(1, 8):
    E0 = [3 ** j for j in range(r)]
    E1 = [0] + [3 ** j for j in range(r - 1)]
    for E, par in ((E0, 0), (E1, 1)):
        assert is_B2(E)
        for m in (len(str(2 * sum(10 ** e for e in E))), 3 ** (r - 1) + 7):
            x = block_x(E, m)
            assert S(x * x) == 18 * m + r * r
            assert x % 2 == par and x % 3 == r % 3

# (3) tail lemma
for _ in range(20000):
    v = rng.randrange(1, 10 ** rng.randrange(1, 12))
    if v % 5 == 0:
        continue
    g = len(str(v * v)) + rng.randrange(0, 3)
    h = 2 * g + rng.randrange(0, 4)
    s = 10 ** h - 10 ** g + v
    assert S(s * s) == 9 * h + S(v * v), (v, g, h)

# (4) the 60-digit witness
v0 = 948683297970914
assert v0 % 2 == 0 and v0 % 5 and len(str(v0 * v0)) == 30 and S(v0 * v0) == 232
s0 = 10 ** 60 - 10 ** 30 + v0
assert len(str(s0)) == 60 and s0 % 2 == 0 and s0 % 3 == 2
assert S(s0 * s0) == 772 and stopping_time(s0 * s0) == 9
assert 1 + phi(s0) == 10                       # sigma(n) = 1 + phi(S(n)) = 10

# an explicit n: s0 ones followed by a zero
# (only its digit sum matters, so we verify the reduction rather than build it)
assert (10 * (10 ** 5 - 1) // 9) % 2 == 0      # shape check on a small analogue
assert S(10 * (10 ** 5 - 1) // 9) == 5

# (5) the 93-digit witness
x93 = block_x([1, 2, 4, 8], 42)
assert len(str(x93)) == 93 and S(x93 * x93) == 772 and x93 % 2 == 0

# lower bound for any witness: S(s^2) >= 772 forces s^2 to have >= 86 digits
assert 9 * 85 < 772
out = {
    "v0": v0, "S(v0^2)": S(v0 * v0), "digits(v0^2)": len(str(v0 * v0)),
    "s0": str(s0), "digits(s0)": len(str(s0)),
    "S(s0^2)": S(s0 * s0), "sigma(s0^2)": stopping_time(s0 * s0), "s0 mod 3": s0 % 3,
    "sigma(n) for even n with S(n)=s0": 1 + phi(s0),
    "x93": str(x93), "digits(x93)": len(str(x93)), "S(x93^2)": S(x93 * x93),
    "min_digits_of_any_s_with_S(s^2)=772": 43,
    "bound_on_smallest_counterexample_digits": ["> 3.5e41", "< 1.2e59"],
}
print(json.dumps(out, indent=2)[:1200])
json.dump(out, open("../results/witness.json", "w"), indent=2)
