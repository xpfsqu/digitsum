"""Numerical validation of the chain construction (Section 5 of the paper).

With E = {3^i + 1 : 0 <= i <= 9} (a B_2-set of r = 10 elements),
V = sum_{e in E} 10^e, m = (y - 100)/18, W = 10^m - 1 and 10^a > max(V^2, 2VW),
the integer x = 10^a W + V is even, satisfies x = 1 (mod 9) and

        S(x^2) = 18m + r^2 = 18m + 100 = y .

This is the inductive step behind the proof that stopping times are unbounded.
It is verified here for several targets y, the largest producing an x with more
than 10^5 decimal digits.
"""
import json, sys, time
from digitmap import S, ndigits

# pass "full" to include the 10^7 target (about two minutes)
TARGETS = (6, 7) if len(sys.argv) > 1 and sys.argv[1] == "full" else (6,)

E = [3 ** i + 1 for i in range(10)]
sums = [e + f for i, e in enumerate(E) for f in E[i:]]
assert len(sums) == len(set(sums))                      # E is a B_2-set
V = sum(10 ** e for e in E)
rows = []
for j in TARGETS:
    y = 10 ** j                                          # even and = 1 (mod 9)
    assert y % 2 == 0 and y % 9 == 1
    m = (y - 100) // 18
    assert 18 * m + 100 == y and 2 * V <= 10 ** m
    W = 10 ** m - 1
    a = max(ndigits(V * V, 10), ndigits(2 * V * W, 10))
    t0 = time.time()
    x = 10 ** a * W + V
    ok = S(x * x) == y
    assert ok and x % 2 == 0 and x % 9 == 1 and x > y
    rows.append({"target_y": f"10^{j}", "m": m, "digits_of_x": ndigits(x, 10),
                 "digits_of_x_squared": ndigits(x * x, 10),
                 "S(x^2)=y": ok, "x_even": True, "x=1 mod 9": True,
                 "seconds": round(time.time() - t0, 1)})
    print(rows[-1])
json.dump(rows, open("../results/chain_step.json", "w"), indent=2)
