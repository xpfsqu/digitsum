"""The nine-step bound and its exact range of validity (base 10).

For t = 1 (mod 3) put psi_0(t) = sigma(t^2) and psi_1(t) = sigma(t^3).
For even n with 3 | n false and S(n) = s >= 2 one has
      sigma(n) = 2 + psi_{s mod 2}(S(s^2)).
Checks performed:
  * psi_p(t) <= 7 for every t = 1 (mod 3) with t <= 771   (=> the 9-step bound)
  * psi_0(772) = 8 and 772 is the least t with max_p psi_p(t) >= 8
  * psi_0(t) <= 8 and psi_1(t) <= 6 for all t <= T_MAX
  * the least even n with 3 !| n and sigma(n) = k, for k = 1..9
"""
import json, sys
from digitmap import psi, phi, S, stopping_time

T_MAX = int(sys.argv[1]) if len(sys.argv) > 1 else 60000

first_bad, bad_even, max0, max1 = None, [], 0, 0
for t in range(1, T_MAX + 1):
    if t % 3 != 1:
        continue
    a, b = psi(t, 0), psi(t, 1)
    max0, max1 = max(max0, a), max(max1, b)
    if max(a, b) >= 8:
        first_bad = t if first_bad is None else first_bad
        if a >= 8:
            bad_even.append(t)

assert all(max(psi(t, 0), psi(t, 1)) <= 7 for t in range(1, 772) if t % 3 == 1)
assert first_bad == 772 and psi(772, 0) == 8

# the bound 9*85 = 765 < 772 is what makes the nine-step theorem work
assert 9 * 85 < 772 <= 9 * 86

least = {}
n = 2
while len(least) < 9:
    if n % 3:
        k = 1 + phi(S(n))
        assert k == stopping_time(n)          # the reduction sigma(n)=1+phi(S(n))
        least.setdefault(k, n)
    n += 2

orb, x = [], 772 ** 2
while x != 1:
    orb.append(x)
    s = sum(map(int, str(x)))
    x = s * s if x % 2 == 0 else s ** 3
orb.append(1)

out = {
    "T_MAX": T_MAX,
    "max_psi_over_t_le_771": max(max(psi(t, 0), psi(t, 1)) for t in range(1, 772) if t % 3 == 1),
    "least_t_with_psi_ge_8": first_bad,
    "psi_0(772)": psi(772, 0),
    "orbit_of_772_squared": orb,
    "max_psi_0_up_to_T_MAX": max0,
    "max_psi_1_up_to_T_MAX": max1,
    "number_of_t_le_T_MAX_with_psi_0_eq_8": len(bad_even),
    "first_20_such_t": bad_even[:20],
    "least_even_n_not_div_3_with_sigma_k": {k: least[k] for k in sorted(least)},
}
print(json.dumps(out, indent=2))
json.dump(out, open("../results/step_bound.json", "w"), indent=2)
