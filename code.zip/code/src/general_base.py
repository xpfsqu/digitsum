"""Base-b theory: cycles for 2 <= b <= 20, and the constructions for even b.

Part 1. For each base b the set V_b = {s^2, s^3 : 1 <= s <= (b-1)K_b} contains
        every periodic point of T_b, so all cycles are found by iterating from
        V_b.  We also record, for each b, whether every n with gcd(n,b-1)=1
        reaches 1 (equivalently, whether 1 is the only cycle meeting that class).

Part 2. Numerical validation of the two digit constructions in base b:
        (block)  S_b(x^2) = 2(b-1)m + r^2  for x = b^a (b^m - 1) + V,
        (chain)  the step used to prove that stopping times are unbounded
                 for every even base b >= 4.
"""
import json
from math import gcd
from digitmap import Sb, Tb, cycles_of, stopping_time, ndigits

out = {"cycles_by_base": {}, "block_lemma_checks": [], "chain_checks": []}

# ---------- Part 1: cycles for 2 <= b <= 20 ----------
for b in range(2, 21):
    cyc, K, smax, V = cycles_of(b)
    cyc = sorted([sorted(c) for c in cyc])
    coprime_bad = []            # cycles other than {1} living in the class gcd(n,b-1)=1
    for c in cyc:
        if c != [1] and all(gcd(v, b - 1) == 1 for v in c):
            coprime_bad.append(c)
    # every orbit meets V_b, so this check settles the whole class
    all_coprime_reach_1 = all(
        stopping_time(v, b) is not None for v in V if gcd(v, b - 1) == 1)
    assert all_coprime_reach_1 == (not coprime_bad)
    out["cycles_by_base"][b] = {
        "K": K, "s_max": smax, "size_of_V": len(V),
        "num_cycles": len(cyc),
        "cycles": cyc,
        "coprime_class_converges": all_coprime_reach_1,
        "obstructing_cycles_in_coprime_class": coprime_bad,
    }

# ---------- Part 2a: the block lemma in base b ----------
def is_B2(E):
    s = [e + f for i, e in enumerate(E) for f in E[i:]]
    return len(s) == len(set(s))

def block_x(b, E, m):
    V = sum(b ** e for e in E)
    W = b ** m - 1
    assert 2 * V <= b ** m
    a = 1
    while b ** a <= max(V * V, 2 * V * W):
        a += 1
    return b ** a * W + V

for b in [3, 4, 6, 8, 10, 12, 16]:
    for r in range(1, 5):
        E = [3 ** i + 1 for i in range(r)]
        assert is_B2(E)
        V = sum(b ** e for e in E)
        m0 = ndigits(2 * V, b)
        for m in (m0, m0 + 3):
            x = block_x(b, E, m)
            lhs, rhs = Sb(x * x, b), 2 * (b - 1) * m + r * r
            assert lhs == rhs, (b, r, m, lhs, rhs)
            assert x % 2 == (0 if b % 2 == 0 else V % 2)
            assert x % (b - 1) == r % (b - 1)
            out["block_lemma_checks"].append(
                {"b": b, "r": r, "m": m, "S_b(x^2)": lhs, "2(b-1)m+r^2": rhs})

# ---------- Part 2b: one step of the chain, for even b ----------
# For even b the paper takes r = b, so that r is even and r = 1 (mod b-1).
# Given an even target y = 1 (mod b-1) with y > b^2, the exponent
# m = (y - b^2)/(2(b-1)) is then a positive integer, and the block lemma
# (validated above) turns it into an even x = 1 (mod b-1) with S_b(x^2) = y.
# Only this arithmetic is checked here; the digit identity is the block lemma.
for b in [4, 6, 8, 10, 12, 16, 20]:
    r = b
    assert r % 2 == 0 and r % (b - 1) == 1 % (b - 1)
    ok = []
    for j in range(2, 9):
        y = b ** j                      # a legitimate first target: S_b(y^2) = 1
        assert y % 2 == 0 and y % (b - 1) == 1 % (b - 1)
        num = y - b ** 2
        assert num % (2 * (b - 1)) == 0, (b, j)
        ok.append({"y": f"b^{j}", "m": num // (2 * (b - 1))})
    out["chain_checks"].append({"b": b, "r": r, "targets": ok[:3], "all_j_2_to_8_ok": True})

# ---------- Part 3: special features of the bases 2 and 10 ----------
# base 2: the only cycle is {1}, so EVERY positive integer reaches 1
c2 = out["cycles_by_base"][2]["cycles"]
assert c2 == [[1]]
out["base2_every_n_reaches_1"] = True

# base 10: for even n with 3 !| n one has T(n) = S(n)^2 = 1 (mod 3), and the
# class 1 (mod 3) is forward invariant; every v in V_10 with v = 1 (mod 3)
# reaches 1.  The same argument needs 3 | b-1 and fails for other such bases:
bad_mod3 = {}
for b in range(4, 21):
    if (b - 1) % 3:
        continue
    _, K, smax, V = cycles_of(b)
    bad = sorted(v for v in V if v % 3 == 1 and stopping_time(v, b) is None)
    bad_mod3[b] = bad
out["bases_with_3_dividing_b_minus_1__nonconvergent_v_in_class_1_mod_3"] = bad_mod3
assert bad_mod3[10] == []          # base 10 works
assert 343 in bad_mod3[4]          # base 4 does not: 343 = 7^3 is a fixed point
# among the bases b = 1 (mod 3) with 4 <= b <= 20, base 10 is the only one
# for which the class 1 (mod 3) converges completely
out["bases_where_class_1_mod_3_converges"] = [b for b, v in bad_mod3.items() if not v]
assert out["bases_where_class_1_mod_3_converges"] == [10]

json.dump(out, open("../results/general_base.json", "w"), indent=2)
for b in range(2, 21):
    d = out["cycles_by_base"][b]
    print("b=%2d  K=%d  |V|=%3d  cycles=%d  coprime class -> 1: %s  %s"
          % (b, d["K"], d["size_of_V"], d["num_cycles"],
             str(d["coprime_class_converges"]),
             "" if d["coprime_class_converges"] else d["obstructing_cycles_in_coprime_class"]))
print("\nblock-lemma checks:", len(out["block_lemma_checks"]), "all passed")
print("chain checks (even bases):", [c["b"] for c in out["chain_checks"]])
print("\nbase 2: only cycle is {1}, so every n reaches 1")
print("bases b = 1 mod 3, non-convergent v in class 1 mod 3:")
for b, v in bad_mod3.items():
    print("   b=%2d -> %s" % (b, v if v else "none (the base-10 mechanism works)"))
