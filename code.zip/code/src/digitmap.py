"""Core routines for the parity-dependent digit-sum map in base b.

For an integer b >= 2 let S_b(n) be the sum of the base-b digits of n and

    T_b(n) = S_b(n)^2   if n is even,
    T_b(n) = S_b(n)^3   if n is odd.

The classical case is b = 10, written S and T.
"""
import sys
from functools import lru_cache

sys.set_int_max_str_digits(0)      # allow very long decimal integers

WINDOW = 10**6                     # forward-invariant window I = [1, 10^6)


def S(n: int) -> int:
    """Decimal digit sum (divide and conquer above 10^4000, so huge n are fast)."""
    if n < 10 ** 4000:
        return sum(map(int, str(n)))
    k = max(1, ndigits(n, 10) // 2)
    q, r = divmod(n, 10 ** k)
    return S(q) + S(r)


def Sb(n: int, b: int) -> int:
    """Base-b digit sum (divide and conquer, so it is usable on huge integers)."""
    if b == 10:
        return S(n)
    if n < b:
        return n
    # split n at b^(k) with k about half the number of digits
    k = max(1, ndigits(n, b) // 2)
    q, r = divmod(n, b ** k)
    return Sb(q, b) + Sb(r, b)


def T(n: int) -> int:
    s = S(n)
    return s * s if n % 2 == 0 else s * s * s


def Tb(n: int, b: int) -> int:
    s = Sb(n, b)
    return s * s if n % 2 == 0 else s * s * s


def ndigits(n: int, b: int) -> int:
    """Number of base-b digits of n >= 1 (doubling search, so it is fast)."""
    if n < b:
        return 1
    lo, hi = 1, 2
    while b ** hi <= n:
        lo, hi = hi, hi * 2
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if b ** mid <= n:
            lo = mid
        else:
            hi = mid
    return lo + 1


def window_exponent(b: int) -> int:
    """Least K >= 4 with (i) ((b-1)K)^3 < b^K  and  (ii) ((b-1)D)^3 < b^(D-1) for all D > K.

    (i) says the window [1, b^K) is forward invariant under T_b;
    (ii) says T_b(n) < n for every n with more than K base-b digits.
    Condition (ii) needs only the single check D = K+1, because
    ((b-1)(D+1))^3/b^D divided by ((b-1)D)^3/b^(D-1) equals ((D+1)/D)^3/b,
    which is < 1 for D >= 4 and b >= 2; the loop below re-checks a range anyway.
    """
    K = 4
    while True:
        inv = ((b - 1) * K) ** 3 < b ** K
        dec = all(((b - 1) * D) ** 3 < b ** (D - 1) for D in range(K + 1, K + 80))
        if inv and dec:
            return K
        K += 1


def image_set(b: int):
    """The finite set V_b containing every periodic point of T_b.

    Every periodic point p lies in the window [1, b^K), and p = T_b(q) for a
    periodic q, which also lies in the window; hence p = s^2 or s^3 with
    1 <= s = S_b(q) <= (b-1)*K.
    """
    K = window_exponent(b)
    smax = (b - 1) * K
    return sorted({s ** e for s in range(1, smax + 1) for e in (2, 3)}), K, smax


def cycles_of(b: int):
    """All periodic orbits of T_b, found by iterating from V_b only."""
    V, D0, smax = image_set(b)
    seen, cycles = {}, []
    for v in V:
        path, x = [], v
        while x not in seen and x not in path:
            path.append(x)
            x = Tb(x, b)
        if x in seen:
            continue
        cyc = [x]
        y = Tb(x, b)
        while y != x:
            cyc.append(y)
            y = Tb(y, b)
        key = tuple(sorted(cyc))
        if key not in [tuple(sorted(c)) for c in cycles]:
            cycles.append(cyc)
        for p in cyc:
            seen[p] = True
    return cycles, D0, smax, V


def orbit(n: int, b: int = 10, limit: int = 10_000):
    seen, out = set(), []
    while n not in seen and len(out) < limit:
        seen.add(n)
        out.append(n)
        n = Tb(n, b)
    out.append(n)
    return out


def stopping_time(n: int, b: int = 10, limit: int = 10_000):
    """sigma_b(n): least k with T_b^k(n) = 1, or None if 1 is never reached."""
    k, seen = 0, set()
    while n != 1:
        if n in seen or k > limit:
            return None
        seen.add(n)
        n = Tb(n, b)
        k += 1
    return k


@lru_cache(maxsize=None)
def psi(t: int, parity: int) -> int:
    """psi_0(t) = sigma(t^2), psi_1(t) = sigma(t^3)  (base 10)."""
    return stopping_time(t ** (2 if parity == 0 else 3))


@lru_cache(maxsize=None)
def phi(s: int) -> int:
    """phi(s) = sigma(s^2); for even n one has sigma(n) = 1 + phi(S(n))."""
    return stopping_time(s * s)
