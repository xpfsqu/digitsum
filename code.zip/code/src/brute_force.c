/* Independent brute-force check (base 10): for every even n < 10^K with
 * 3 !| n, iterate T directly and record the stopping time.  The histogram for
 * each decade is printed, to be compared with the exact counts computed by
 * distribution.py from the digit-sum reduction.
 *
 * Usage: ./brute_force [K]          (default K = 8)
 */
#include <stdio.h>
#include <stdlib.h>
typedef unsigned long long u64;
static u64 S(u64 x){u64 s=0; while(x){s+=x%10; x/=10;} return s;}
static u64 T(u64 x){u64 s=S(x); return (x&1)? s*s*s : s*s;}

int main(int argc,char**argv){
  int K = argc>1 ? atoi(argv[1]) : 8;
  u64 limit=1; for(int i=0;i<K;i++) limit*=10;
  u64 hist[40]={0}, next=10; int k=1, maxst=0; u64 argmax=0;
  for(u64 n=2;n<limit;n+=2){
    if(n==next){
      printf("k=%d:",k);
      for(int j=0;j<40;j++) if(hist[j]) printf(" %d:%llu",j,hist[j]);
      printf("\n"); fflush(stdout);
      k++; next*=10;
    }
    if(n%3==0) continue;
    u64 x=n; int st=0;
    while(x!=1){ x=T(x); st++;
      if(st>35){ printf("NO CONVERGENCE at n=%llu\n",n); return 1; } }
    hist[st]++;
    if(st>maxst){ maxst=st; argmax=n; }
  }
  printf("k=%d:",k);
  for(int j=0;j<40;j++) if(hist[j]) printf(" %d:%llu",j,hist[j]);
  printf("\nmax stopping time %d (first attained at n=%llu)\n",maxst,argmax);
  return 0;
}
