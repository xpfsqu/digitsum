"""Exact distribution of sigma(n) over E_k = {n < 10^k : n even, 3 !| n}.

Since sigma(n) = 1 + phi(S(n)) for such n, the distribution follows from the
distribution of the digit sum: the number of n < 10^k that are even and have
digit sum s is the coefficient of x^s in
      (1 + x + ... + x^9)^(k-1) (1 + x^2 + x^4 + x^6 + x^8).
Exact integer counts are produced for k <= 12 and floating-point proportions
for larger k.  The two figures of the paper are also generated here.
"""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from digitmap import phi, psi

def digit_sum_counts_exact(k):
    poly = [1]
    for _ in range(k - 1):
        new = [0] * (len(poly) + 9)
        for i, c in enumerate(poly):
            if c:
                for d in range(10):
                    new[i + d] += c
        poly = new
    last = [1, 0, 1, 0, 1, 0, 1, 0, 1]
    out = [0] * (len(poly) + 8)
    for i, c in enumerate(poly):
        for d, e in enumerate(last):
            if e:
                out[i + d] += c
    return out

def digit_sum_probs(k):
    p, u = np.array([1.0]), np.full(10, 0.1)
    for _ in range(k - 1):
        p = np.convolve(p, u)
    return np.convolve(p, np.array([1, 0, 1, 0, 1, 0, 1, 0, 1]) / 5.0)

def dist_exact(k):
    hist = {}
    for s, cnt in enumerate(digit_sum_counts_exact(k)):
        if s == 0 or s % 3 == 0 or cnt == 0:
            continue
        hist[1 + phi(s)] = hist.get(1 + phi(s), 0) + cnt
    return dict(sorted(hist.items()))

def dist_float(k):
    p = digit_sum_probs(k)
    hist, tot = {}, 0.0
    for s, w in enumerate(p):
        if s == 0 or s % 3 == 0 or w == 0:
            continue
        hist[1 + phi(s)] = hist.get(1 + phi(s), 0.0) + w
        tot += w
    return {v: float(hist[v] / tot) for v in sorted(hist)}

results = {"exact_counts": {k: dist_exact(k) for k in range(1, 13)},
           "proportions": {k: dist_float(k) for k in
                           [1, 2, 3, 6, 9, 12, 20, 50, 100, 200, 500, 1000, 2000, 5000]}}
json.dump(results, open("../results/distribution.json", "w"), indent=2)
for k in (3, 6, 8, 12):
    print(k, results["exact_counts"][k])

plt.rcParams.update({"font.size": 9, "font.family": "serif"})

# Figure 1: psi_0 and psi_1 on the class 1 (mod 3)
ts = [t for t in range(1, 3001) if t % 3 == 1]
y0, y1 = [psi(t, 0) for t in ts], [psi(t, 1) for t in ts]
fig, ax = plt.subplots(figsize=(6.0, 2.7))
ax.scatter(ts, [y - 0.22 for y in y1], s=2, color="0.6",
           label=r"$\psi_1(t)=\sigma(t^3)$ (offset $-0.22$)")
ax.scatter(ts, y0, s=3, color="k", label=r"$\psi_0(t)=\sigma(t^2)$")
ax.axvline(772, ls="--", lw=0.8, color="k")
ax.annotate(r"$t=772$", xy=(772, 8), xytext=(1030, 8.3), fontsize=8,
            arrowprops=dict(arrowstyle="->", lw=0.6))
ax.set_xlabel(r"$t$   ($t \equiv 1$ mod 3)")
ax.set_ylabel("stopping time")
ax.set_yticks(range(0, 10)); ax.set_ylim(-0.4, 9)
ax.legend(loc="lower right", fontsize=8, frameon=False)
fig.tight_layout(); fig.savefig("../figures/fig_psi.pdf"); fig.savefig("../figures/fig_psi.png", dpi=200)

# Figure 2: distribution of sigma on E_k
ks = [3, 6, 12, 100, 1000, 5000]
fig, ax = plt.subplots(figsize=(6.0, 2.7))
width, greys = 0.13, ["0.9", "0.75", "0.6", "0.42", "0.22", "0.0"]
for i, k in enumerate(ks):
    d = results["proportions"][k]
    xs = np.arange(1, 10)
    ax.bar(xs + (i - 2.5) * width, [d.get(v, 0) for v in xs], width,
           color=greys[i], edgecolor="k", linewidth=0.3, label=rf"$k={k}$")
ax.set_xlabel(r"$\sigma(n)$"); ax.set_ylabel("proportion")
ax.set_xticks(range(1, 10))
ax.legend(ncol=3, fontsize=7.5, frameon=False, loc="upper left")
fig.tight_layout(); fig.savefig("../figures/fig_distribution.pdf"); fig.savefig("../figures/fig_distribution.png", dpi=200)
print("figures written")
