"""Theorem: the periodic orbits of T (base 10) and the convergent classes.

Two independent verifications are performed.

(A) Localisation method (the proof used in the paper).
    Every periodic point lies in the window [1, 10^6) and is a value of T,
    hence lies in V = {s^2, s^3 : 1 <= s <= 54}, a set of 105 integers.
    Iterating T from these 105 integers therefore finds every cycle.
    Likewise every orbit meets V, so a statement of the form "every n in a
    forward-invariant class C reaches 1" only has to be checked on V ∩ C.

(B) Exhaustive enumeration of the whole window [1, 10^6), which also yields
    the sizes of the basins of attraction (Table 1).
"""
import json, time
from collections import Counter
from digitmap import T, S, WINDOW, cycles_of, stopping_time

t0 = time.time()
out = {}

# ---------- (A) localisation ----------
cyc, K, smax, V = cycles_of(10)
cyc_sorted = sorted([sorted(c) for c in cyc])
out["K"] = K
out["s_max"] = smax
out["size_of_V"] = len(V)
out["cycles_from_V"] = cyc_sorted
assert cyc_sorted == [[1], [81, 324, 729, 5832], [4913], [19683]]

# forward invariance of the window, and strict decrease above it
assert (9 * K) ** 3 < 10 ** K
assert all((9 * D) ** 3 < 10 ** (D - 1) for D in range(K + 1, K + 80))

# which elements of V reach 1, by residue class and parity
classes = {}
for v in V:
    st = stopping_time(v)
    classes.setdefault((v % 3, v % 2), set()).add(st is not None)
out["V_reaches_1_by_(mod3,parity)"] = {f"{a},{b}": sorted(x) for (a, b), x in sorted(classes.items())}
# the two statements used in the paper
assert all(stopping_time(v) is not None for v in V if v % 3 == 1)
assert all(stopping_time(v) is not None for v in V if v % 3 == 2 and v % 2 == 0)
out["every_v_in_V_with_v=1_mod_3_reaches_1"] = True
out["every_even_v_in_V_with_v=2_mod_3_reaches_1"] = True
# sharpness: some odd v = 2 mod 3 does not reach 1, and some v = 0 mod 3 does not
out["odd_v_in_V_with_v=2_mod_3_failing"] = sorted(v for v in V if v % 3 == 2 and v % 2 and stopping_time(v) is None)[:5]

# ---------- (B) exhaustive enumeration of [1, 10^6) ----------
label, cycles, cyc_index = {}, [], {}
for m in range(1, WINDOW):
    path, x = [], m
    while x not in label and x not in path:
        path.append(x)
        x = T(x)
    if x in label:
        c = label[x]
    else:
        cy = [x]
        y = T(x)
        while y != x:
            cy.append(y)
            y = T(y)
        key = tuple(sorted(cy))
        if key not in cyc_index:
            cyc_index[key] = len(cycles)
            cycles.append(key)
        c = cyc_index[key]
    for p in path:
        label[p] = c
    assert all(v < WINDOW for v in path)          # forward invariance

assert sorted(map(list, cycles)) == cyc_sorted    # (A) and (B) agree
one = cyc_index[(1,)]
assert not [m for m in range(1, WINDOW) if m % 3 == 1 and label[m] != one]
assert not [m for m in range(1, WINDOW) if m % 3 == 2 and m % 2 == 0 and label[m] != one]

st = {1: 0}
def sigma(m):
    chain = []
    while m not in st:
        chain.append(m)
        m = T(m)
    k = st[m]
    for p in reversed(chain):
        k += 1
        st[p] = k
    return st[chain[0]] if chain else k

vals = [(sigma(m), m) for m in range(1, WINDOW) if m % 3 == 1]
mx = max(v for v, _ in vals)
out["max_sigma_on_class_1_mod_3_below_1e6"] = mx
out["smallest_argmax"] = min(m for v, m in vals if v == mx)
out["number_attaining_max"] = sum(1 for v, _ in vals if v == mx)

table = Counter()
for m in range(1, WINDOW):
    table[(m % 3, m % 2, cycles[label[m]])] += 1
out["basins_by_(m mod 3, m mod 2)"] = {
    f"{a},{b}: {list(c)}": v for (a, b, c), v in sorted(table.items())}
out["seconds"] = round(time.time() - t0, 1)

print(json.dumps(out, indent=2))
json.dump(out, open("../results/cycles_and_basins.json", "w"), indent=2)
