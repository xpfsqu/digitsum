/* Randomised search for even v with 5 !| v whose square has q decimal digits
 * and digit sum exactly `target`.  Such v feed the tail construction
 *      s = 10^h - 10^g + v,   S(s^2) = 9h + S(v^2),
 * used to build small witnesses against the nine-step bound.
 *
 * Usage: ./dense_square_search q target iterations [seed]
 */
#include <stdio.h>
#include <stdlib.h>
typedef unsigned __int128 u128;
typedef unsigned long long u64;

static int dsum(u128 x){int s=0;while(x){u64 c=(u64)(x%1000000000000000000ULL);x/=1000000000000000000ULL;
  while(c){s+=c%10;c/=10;}}return s;}
static u64 rng=88172645463325252ULL;
static u64 xr(){rng^=rng<<13;rng^=rng>>7;rng^=rng<<17;return rng;}
static u128 isqrt128(u128 n){u128 x=1; u128 t=n; while(t){x<<=1;t>>=2;} 
  while(1){u128 y=(x+n/x)>>1; if(y>=x)break; x=y;} while(x*x>n)x--; while((x+1)*(x+1)<=n)x++; return x;}

int main(int argc,char**argv){
  if(argc<4){fprintf(stderr,"usage: %s q target iters [seed]\n",argv[0]);return 2;}
  int q=atoi(argv[1]), target=atoi(argv[2]); long long iters=atoll(argv[3]);
  if(argc>4) rng=strtoull(argv[4],0,10);
  u128 P10=1; for(int i=0;i<q;i++)P10*=10;
  int k=9; u128 sc=1; for(int i=0;i<q-k;i++) sc*=10;   /* scale of a 9-digit prefix */
  int best=0; long long found=0;
  for(long long it=0; it<iters && found<5; it++){
    u64 P=0;                                   /* 9-digit prefix, biased towards 9s */
    for(int i=0;i<k;i++){int d=(xr()%10<7)?9:(int)(xr()%10); if(i==0&&d==0)d=9; P=P*10+d;}
    u128 lo=isqrt128((u128)P*sc), hi=isqrt128((u128)(P+1)*sc);
    u128 span = hi>lo ? hi-lo : 1;
    u128 v=lo+(u128)(xr()%(u64)(span>1000000000ULL?1000000000ULL:span));
    v &= ~(u128)1;                             /* make it even */
    for(int j=0;j<4000;j++, v+=2){
      if(v%5==0) continue;
      u128 w=v*v;
      if(w>=P10 || w<P10/10) continue;
      int s=dsum(w);
      if(s>best) best=s;
      if(s==target){
        char buf[64]; int n=0; u128 t=v; while(t){buf[n++]='0'+(int)(t%10);t/=10;}
        printf("FOUND q=%d S(v^2)=%d v=",q,s); while(n--)putchar(buf[n]); putchar('\n');
        fflush(stdout); found++; break;
      }
    }
  }
  printf("best digit sum seen: %d\n",best);
  return found?0:1;
}
