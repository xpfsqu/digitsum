# A parity-dependent digit-sum iteration — code and data

Companion software for

> Y. Jia and P. Xu, *A parity-dependent digit-sum iteration: cycles, convergence
> and unbounded stopping times*, submitted to the Rocky Mountain Journal of Mathematics.

For a base `b` let `S_b(n)` be the sum of the base-`b` digits of `n` and

```
T_b(n) = S_b(n)^2   if n is even,
T_b(n) = S_b(n)^3   if n is odd,
```

with `S = S_10`, `T = T_10`. The stopping time `sigma_b(n)` is the least `k` with
`T_b^k(n) = 1`.

## Quick start

```sh
pip install -r requirements.txt
./run_all.sh            # about two minutes
./run_all.sh full       # adds the largest chain-construction check (a few minutes more)
```

Every proof-relevant computation uses exact integer arithmetic: Python big integers
and, independently, C with 64-bit integers. Floating point is used only for the
proportions with `k > 12` drawn in Figure 2.

## What each file verifies

| file | statement in the paper |
|------|------------------------|
| `src/digitmap.py` | core routines: `S`, `S_b`, `T_b`, `sigma_b`, `psi_0`, `psi_1`, the window constant `K_b` of Lemma 2.2 and the localising set `V_b` of Lemma 2.3 |
| `src/verify_cycles.py` | Lemma 3.1, Theorem 1.1, Table 1 — the four cycles of `T`, by two independent methods, and the convergent residue classes |
| `src/verify_step_bound.py` | Lemma 4.1, Theorem 1.2, Remark 4.2 — `psi_p(t) <= 7` for `t <= 771`, `psi_0(772) = 8`, data up to `t = 60000` |
| `src/witness.py` | Lemmas 5.1–5.3, Theorem 5.4, Remark 5.5 — the three digit constructions and the 60-digit and 93-digit witnesses |
| `src/chain_step.py` | Lemma 5.7, Theorem 5.8, Remark 5.9 — one step of the chain construction, carried out explicitly |
| `src/general_base.py` | Lemma 6.1, Theorem 1.4, Table 3, Remark 6.2 — all cycles for `2 <= b <= 20`, the block lemma in base `b`, and the arithmetic of the even-base chain |
| `src/distribution.py` | Table 2 and Figures 1–2 — the exact distribution of `sigma` on `E_k` |
| `src/brute_force.c` | independent brute-force check of every even `n < 10^8` with `3` not dividing `n` |
| `src/dense_square_search.c` | the randomised search that produced `v0 = 948683297970914` (`./dense_square_search 30 232 2000000`) |
| `results/*.json`, `results/*.txt` | the outputs of the programs above |
| `figures/` | the figures of the paper, as PDF and PNG |

## Main facts reproduced

* The periodic orbits of `T` are `{1}`, `{4913}`, `{19683}` and `81 -> 729 -> 5832 -> 324`.
  Only 105 integers have to be examined to prove this (Lemma 2.3).
* Every even `n` with `3` not dividing `n` reaches 1, and `sigma(n) <= 9` whenever
  `S(n) < 10^42.5`.
* `s0 = 10^60 - 10^30 + 948683297970914` satisfies `S(s0^2) = 772`, so every even `n`
  with digit sum `s0` needs exactly **ten** steps: the nine-step bound is false.
* One step of the chain construction: an explicit even `x` with 130 785 decimal digits
  and `S(x^2) = 10^6` exactly (and, in `full` mode, one with 1 130 785 digits).
* In base 2 the only cycle is `{1}`; the complete cycle lists for `2 <= b <= 20` are
  computed, and base 10 is the only base `b = 1 (mod 3)` with `4 <= b <= 20` for which
  the class `1 (mod 3)` converges completely.
* The brute-force enumeration below `10^8` agrees exactly with the counts obtained from
  the digit-sum reduction.

## Origin of the problem

The conjecture that nine steps always suffice was posed in an online forum thread in
July 2008 (`https://bbs.csdn.net/topics/240061998`), cited as reference [10] of the
paper. The thread contains numerical experiments and discussion only; the present work
supplies the proofs, and disproves the conjecture in general.

## License

MIT (see `LICENSE`).
